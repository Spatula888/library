<?php
// DB credentials.
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'library');

try {
    // Establish database connection.
    $dbh = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'")
    );

    // Set PDO to throw exceptions on error.
    $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Connection successful message (optional)
    // echo "Connected to the database successfully";

} catch (PDOException $e) {
    // Handle connection error with a more detailed error message
    exit("Error: Unable to connect to the database. Reason: " . $e->getMessage());
}
?>
