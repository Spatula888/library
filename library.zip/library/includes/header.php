<div class="navbar navbar-inverse set-radius-zero" >
        <div class="container-fluid p-0">
            <div class="row">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- Move the logo to the top-right and make it smaller -->
<a class="col-12 p-0" style="margin-top: 10px;font-size: 36px;">
    <img src="assets/img/school.png" style="width:1800px; height:300px;"alt="image" />
</a>


            </div>
<?php if($_SESSION['login'])
{
?> 
            <div class="right-div">
                <a href="logout.php" class="btn btn-danger pull-right">LOG OUT</a>
            </div>
            <?php }?>
        </div>
    </div>
    <!-- LOGO HEADER END-->
<?php if($_SESSION['login'])
{
?>    
<section class="menu-section">
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                        <li><a href="dashboard.php" class="menu-top-active"><i class="fas fa-chart-bar"></i> DASHBOARD</a></li>
                            <li><a href="issued-books.php">BORROWED BOOKS</a></li>
                             <li>
                                <a href="#" class="dropdown-toggle" id="ddlmenuItem" data-toggle="dropdown"> ACCOUNT <i class="fa fa-angle-down"></i></a>
                                <ul class="dropdown-menu" role="menu" aria-labelledby="ddlmenuItem">
                                    <li role="presentation"><a role="menuitem" tabindex="-1" href="my-profile.php">MY PROFILE</a></li>
                                     <li role="presentation"><a role="menuitem" tabindex="-1" href="change-password.php">Change Password</a></li>
                                </ul>
                            </li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <?php } else { ?>
        <section class="menu-section">
           
        <div class="container">
            <div class="row ">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">                        
                          
                        <li>
    <a href="index.php" style="text-decoration: none; color: #333; font-weight: bold;">
        <i class="fas fa-home" style="color: blue;"></i> HOME
    </a>
</li>


<li>
            <a href="index.php#ulogin" style="text-decoration: none; color: #333; font-weight: bold;">
                <i class="fas fa-user" style="color: green;"></i> STUDENTs LOGIN
            </a>
        </li>
        <li><a href="signup.php"><i class="fas fa-users" style="color:green;"></i> STUDENT REGISTRATION</a></li>
                         
        <li><a href="adminlogin.php"><span class="glyphicon glyphicon-lock"></span> ADMIN LOGIN</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <?php } ?> 