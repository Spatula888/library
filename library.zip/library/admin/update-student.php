<?php
include('includes/config.php');

if(isset($_POST['update'])) {
    // Get the updated information from the form
    $id = $_POST['student_id']; // Assuming the field name is 'student_id'
    $fullName = $_POST['full_name']; // Assuming the field name is 'full_name'

// Split the full name into components
$nameComponents = explode(" ", $fullName);

$firstName = $nameComponents[0];
$lastName = end($nameComponents); // Last element will be the last name

// Remove the first and last names to extract the middle name(s)
array_pop($nameComponents); // Remove last element (last name)
array_shift($nameComponents); // Remove first element (first name)

// Whatever remains in $nameComponents is the middle name(s)
$middleName = implode(" ", $nameComponents);

    $email = $_POST['email']; // Assuming the field name is 'email'
    $mobileNumber = $_POST['mobile_number']; // Assuming the field name is 'mobile_number'
    
    // Perform data validation and sanitization if required
    
    // Update the student record in the database
    $sql = "UPDATE tblstudents SET FullName = :fullName, EmailId = :email, MobileNumber = :mobileNumber WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_STR);
    $query->bindParam(':fullName', $fullName, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':mobileNumber', $mobileNumber, PDO::PARAM_STR);
    
    if($query->execute()) {
        // If update is successful, redirect back to reg-students.php
        header('location: reg-students.php');
        exit;
    } else {
        // Handle update failure
        // Display an error message or perform necessary actions
    }
} else {
    // Handle cases where 'update' was not set in $_POST
    // Redirect or perform actions accordingly
}
?>
