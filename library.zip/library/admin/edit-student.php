<!DOCTYPE html>
<html>
<head>
    <title>Edit Student Information</title>
    <style>
        .form-container {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            padding: 10px 15px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>

<?php
include('includes/config.php');
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM tblstudents WHERE id = :id";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_STR);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_ASSOC);
}
?>

<div class="form-container">
    <form method="post" action="update-student.php">
        <div class="form-group">
            <label for="full_name">Full Name:</label>
            <!-- Populate retrieved full name into the input field -->
            <input type="text" id="full_name" name="full_name" value="<?php echo htmlentities($result['FullName']); ?>">
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <!-- Populate retrieved email into the input field -->
            <input type="email" id="email" name="email" value="<?php echo htmlentities($result['EmailId']); ?>">
        </div>

        <div class="form-group">
            <label for="mobile_number">Mobile Number:</label>
            <!-- Populate retrieved mobile number into the input field -->
            <input type="text" id="mobile_number" name="mobile_number" value="<?php echo htmlentities($result['MobileNumber']); ?>">
        </div>
        
        <button type="submit" name="update">Update</button>
    </form>
</div>


</body>
</html>

