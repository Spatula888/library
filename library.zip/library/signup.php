<?php
session_start();
include('includes/config.php');
error_reporting(0);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['signup'])) {
    // Generate unique student ID
    $count_my_page = "studentid.txt";
    $hits = file($count_my_page);
    $hits[0]++;
    $fp = fopen($count_my_page, "w");
    fputs($fp, "$hits[0]");
    fclose($fp);
    $StudentId = $hits[0];

    // Get form data
    $fname = $_POST['firstname'];
    $mobileno = $_POST['mobileno'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $grade_level = $_POST['grade_level']; // Retrieve grade level from the form
    $status = 1;

    // Insert data into database with Grade Level
    $sql = "INSERT INTO tblstudents(StudentId, FullName, MobileNumber, EmailId, Password, GradeLevel, Status) VALUES(:StudentId, :fname, :mobileno, :email, :password, :grade_level, :status)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':StudentId', $StudentId, PDO::PARAM_STR);
    $query->bindParam(':fname', $fname, PDO::PARAM_STR);
    $query->bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->bindParam(':grade_level', $grade_level, PDO::PARAM_INT); // Bind grade level parameter
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->execute();

    $lastInsertId = $dbh->lastInsertId();

    if ($lastInsertId) {
        echo '<script>alert("Registration successful! Your student ID is ' . $StudentId . '")</script>';
    } else {
        echo "<script>alert('Something went wrong. Please try again');</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $sid = $_SESSION['stdid'];
    $fname = $_POST['fullname'];

    // Update the user's profile in the database
    $sql = "UPDATE tblstudents SET FullName=:fname WHERE StudentId=:sid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':sid', $sid, PDO::PARAM_STR);
    $query->bindParam(':fname', $fname, PDO::PARAM_STR);
    $query->execute();

    // Fetch updated profile information
    $sql = "SELECT StudentId, FullName, EmailId, MobileNumber, RegDate, UpdationDate, Status FROM tblstudents WHERE StudentId = :sid";
    $query = $dbh->prepare($sql);
    $query->bindParam(':sid', $sid, PDO::PARAM_STR);
    $query->execute();
    $result = $query->fetch(PDO::FETCH_OBJ);

    // Update session variables with updated profile data
    $_SESSION['user_profile'] = $result;

    echo '<script>alert("Your profile has been updated")</script>';
}
?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Mauraro WebBased Library Management System | Student Signup</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
<script type="text/javascript">
function valid()
{
if(document.signup.password.value!= document.signup.confirmpassword.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.signup.confirmpassword.focus();
return false;
}
return true;
}
</script>
<script>
function checkAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#emailid").val(),
type: "POST",
success:function(data){
$("#user-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}
</script>    
<script>
    function displayGender() {
    var selectedGender = document.getElementById("gender").value;
    var displaySpan = document.getElementById("selected-gender");
    
    if (selectedGender.toLowerCase() === 'male') {
        displaySpan.textContent = 'You chose male';
        // Perform actions specific to male gender
    } else if (selectedGender.toLowerCase() === 'female') {
        displaySpan.textContent = 'You chose female';
        // Perform actions specific to female gender
    } else {
        displaySpan.textContent = 'Please choose either male or female.';
    }
}

 function calculateAge() {
            const birthday = new Date(document.getElementById('birthday').value);
            const today = new Date();
            
            let age = today.getFullYear() - birthday.getFullYear();
            const monthDiff = today.getMonth() - birthday.getMonth();
            
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthday.getDate())) {
                age--;
            }
            
            document.getElementById('age').textContent = age;
        }
</script>

</head>
<body>
    <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">STUDENT REGISTRATION</h4>
                
                            </div>

        </div>
             <div class="row">
           
<div class="col-md-9 col-md-offset-1">
               <div class="panel panel-primary">
                        <div class="panel-heading">
                           REGISTRATION FORM
                        </div>
                        <div class="panel-body">
                        <form name="signup" method="post" onSubmit="return valid();">
        <!-- Adjusted form fields -->
        <div class="form-group">
            <label>First Name</label><br>
            <input class="form-control" type="text" name="firstname" pattern="[A-Za-z ]+" autocomplete="off" required /><br>
            <label>Middle Name (optional)</label>
    <input class="form-control" type="text" name="middlename" pattern="[A-Za-z ]+" autocomplete="off" />
    <small class="form-text text-muted">You may leave this field blank if you don't have a middle name.</small><br>
            <label>Last Name</label>
            <input class="form-control" type="text" name="lastname" pattern="[A-Za-z ]+" autocomplete="off" required />
        </div>
        <div class="form-group">
        <label for="birthday">Birthday:</label>
    <input type="date" id="birthday" name="birthday" onchange="calculateAge()" required>

    <p>Your age is: <span id="age"></span></p>
    </div>
        <div class="form-group">
    <label>GENDER</label><br>
    <input type="radio" id="male" name="gender" value="male">
    <label for="male">Male</label><br>
    <input type="radio" id="female" name="gender" value="female">
    <label for="female">Female</label><br>
    
</div>
<div class="form-group">
    <label>GRADE LEVEL</label>
    <select class="form-control" name="GradeLevel" required>
        <option value="">Select Grade Level</option>
        <optgroup label="Junior High School">
            <optgroup label="Grade 7">
                <option value="JHS7S1">Grade 7 - Section 1</option>
                <option value="JHS7S2">Grade 7 - Section 2</option>
                <option value="JHS7S3">Grade 7 - Section 3</option>
                <option value="JHS7S4">Grade 7 - Section 4</option>
            </optgroup>
            <optgroup label="Grade 8">
                <option value="JHS8S1">Grade 8 - Section 1</option>
                <option value="JHS8S2">Grade 8 - Section 2</option>
                <option value="JHS8S3">Grade 8 - Section 3</option>
                <option value="JHS8S4">Grade 8 - Section 4</option>
            </optgroup>
            <optgroup label="Grade 9">
                <option value="JHS9S1">Grade 9 - Section 1</option>
                <option value="JHS9S2">Grade 9 - Section 2</option>
                <option value="JHS9S3">Grade 9 - Section 3</option>
                <option value="JHS9S4">Grade 9 - Section 4</option>
            </optgroup>
            <optgroup label="Grade 10">
                <option value="JHS10S1">Grade 10 - Section 1</option>
                <option value="JHS10S2">Grade 10 - Section 2</option>
                <option value="JHS10S3">Grade 10 - Section 3</option>
                <option value="JHS10S4">Grade 10 - Section 4</option>
            </optgroup>
        </optgroup>
        <optgroup label="Senior High School">
            <optgroup label="Grade 11">
                <option value="SHS11Strand1">Grade 11 - Strand 1</option>
                <option value="SHS11Strand2">Grade 11 - Strand 2</option>
                <option value="SHS11Strand3">Grade 11 - Strand 3</option>
                <option value="SHS11Strand4">Grade 11 - Strand 4</option>
                <option value="SHS11Strand5">Grade 11 - Strand 5</option>
            </optgroup>
            <optgroup label="Grade 12">
                <option value="SHS12Strand1">Grade 12 - Strand 1</option>
                <option value="SHS12Strand2">Grade 12 - Strand 2</option>
                <option value="SHS12Strand3">Grade 12 - Strand 3</option>
                <option value="SHS12Strand4">Grade 12 - Strand 4</option>
                <option value="SHS12Strand5">Grade 12 - Strand 5</option>
            </optgroup>
        </optgroup>
    </select>
</div>
<div class="form-group">
    <label for="LRN">LEARNING REFERENCE NUMBER</label>
    <input class="form-control" type="text" id="LRN" name="LRN" pattern="^\d{12}$" title="Please enter exactly 12 digits" maxlength="12" placeholder="Enter LRN (12 digits)" required>
</div>





        <div class="form-group">
    <label for="street">STREET ADDRESS</label>
    <input class="form-control" type="text" id="street" name="street" placeholder="Enter Street Address" required>
    <label for="country">BARANGAY</label>
    <input class="form-control" type="text" id="country" name="country" placeholder="Enter Country" required>
    <label for="city">MUNICIPALITY</label>
    <input class="form-control" type="text" id="city" name="city" placeholder="Enter City" required>
    <label for="state">REGION/PROVINCE</label>
    <input class="form-control" type="text" id="state" name="state" placeholder="Enter State/Province/Region" required>
    <label for="zip">ZIP/POSTAL CODE</label>
    <input class="form-control" type="text" id="zip" name="zip" placeholder="Enter ZIP/Postal Code" required>
    
</div>

        <div class="form-group">
            <label>MOBILE NUMBER :</label>
            <input class="form-control" type="text" name="mobileno" maxlength="10" autocomplete="off" required />
            <div class="form-group">
        <label>EMAIL</label>
        <input class="form-control" type="email" name="email" id="emailid" onBlur="checkAvailability()" autocomplete="off" required />
        <span id="user-availability-status" style="font-size:12px;"></span>
        <label>PASSWORD</label>
        <input class="form-control" type="password" name="password" autocomplete="off" required />
    </div>
    <button type="submit" name="signup" class="btn btn-success" id="submit">SUBMIT</button>
</form>
                            </div>
                        </div>
                            </div>
        </div>
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
