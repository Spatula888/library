<?php
session_start();

// Preserve specific session variables
$student_name = $_SESSION['student_name'];
$student_id = $_SESSION['student_id'];

// Destroy the session
session_destroy();

// Start a new session
session_start();

// Restore preserved session variables
$_SESSION['student_name'] = $student_name;
$_SESSION['student_id'] = $student_id;

header("location:index.php");
exit;
?>
